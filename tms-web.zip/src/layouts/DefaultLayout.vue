
<template>
  <div class="container">
    <h1>人材管理</h1>
    <div class="card">
      <slot />
    </div>
  </div>
</template>
<script setup lang="ts"></script>
