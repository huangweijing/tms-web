
<template>
  <table>
    <thead>
      <tr>
        <th>人材ID</th>
        <th>所属会社</th>
        <th>名前</th>
        <th>社員番号</th>
        <th>生年月日</th>
        <th>現案件終了</th>
        <th>BP</th>
        <th>削除</th>
        <th style="width: 180px;">操作</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="p in items" :key="p.人材ID" @dblclick="emit('edit', p)">
        <td><span class="kbd">{{ p.人材ID }}</span></td>
        <td>{{ p.所属会社 }}</td>
        <td>{{ p.名前 }}</td>
        <td>{{ p.社員番号 }}</td>
        <td>{{ formatYmd(p.生年月日) }}</td>
        <td>{{ formatYmd(p.現案件終了年月日) }}</td>
        <td><span class="badge">{{ p.BPフラグ }}</span></td>
        <td><span class="badge">{{ p.削除フラグ }}</span></td>
        <td class="tr-actions">
          <button class="btn" @click="emit('edit', p)">編集</button>
          <button class="btn danger" @click="emit('delete', p)">削除</button>
        </td>
      </tr>
      <tr v-if="!items?.length">
        <td colspan="9" style="text-align:center; color: var(--muted); padding: 24px;">データがありません</td>
      </tr>
    </tbody>
  </table>
</template>

<script setup lang="ts">
import type { Personnel } from './types'

defineProps<{ items: Personnel[] }>()

const emit = defineEmits<{
  (e: 'edit', p: Personnel): void
  (e: 'delete', p: Personnel): void
}>()

function formatYmd(s: string) {
  if (!s || s.length !== 8) return s
  return `${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}`
}
</script>
