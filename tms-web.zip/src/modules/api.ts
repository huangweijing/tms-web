
import type { PageResponse, Personnel } from './types'

const BASE = import.meta.env.VITE_API_BASE || '/api'
const USE_MOCK = (import.meta.env.VITE_USE_MOCK || 'false').toLowerCase() === 'true'

let mock: Personnel[] = []
async function loadMock() {
  if (mock.length) return
  const data = await fetch('/src/modules/mockData.json')
  mock = await data.json()
}

type Query = { page?: number; size?: number; keyword?: string; bp?: number | undefined }

export const Api = {
  async list(q: Query): Promise<PageResponse<Personnel>> {
    if (!USE_MOCK) {
      const params = new URLSearchParams()
      if (q.page) params.set('page', String(q.page))
      if (q.size) params.set('size', String(q.size))
      if (q.keyword) params.set('keyword', q.keyword)
      if (q.bp !== undefined) params.set('bp', String(q.bp))
      const res = await fetch(`${BASE}/personnel?${params.toString()}`)
      if (!res.ok) throw new Error('Failed to fetch list')
      return await res.json()
    } else {
      await loadMock()
      const { page = 1, size = 10, keyword, bp } = q
      let data = [...mock]
      if (keyword) {
        const kw = keyword.toLowerCase()
        data = data.filter(x => x.名前.toLowerCase().includes(kw) || x.所属会社.toLowerCase().includes(kw))
      }
      if (bp !== undefined) data = data.filter(x => x.BPフラグ === bp)
      const total = data.length
      const start = (page - 1) * size
      const items = data.slice(start, start + size)
      return { items, page, size, total }
    }
  },

  async create(p: Omit<Personnel, '人材ID'> & { 人材ID?: string }): Promise<Personnel> {
    if (!USE_MOCK) {
      const res = await fetch(`${BASE}/personnel`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(p) })
      if (!res.ok) throw new Error('Failed to create')
      return await res.json()
    } else {
      await loadMock()
      const id = crypto.randomUUID?.() ?? Math.random().toString(36).slice(2)
      const created: Personnel = { ...p, 人材ID: id } as Personnel
      mock.unshift(created)
      return created
    }
  },

  async update(id: string, p: Partial<Personnel>): Promise<Personnel> {
    if (!USE_MOCK) {
      const res = await fetch(`${BASE}/personnel/${id}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(p) })
      if (!res.ok) throw new Error('Failed to update')
      return await res.json()
    } else {
      await loadMock()
      const i = mock.findIndex(x => x.人材ID === id)
      if (i >= 0) {
        mock[i] = { ...mock[i], ...p, 人材ID: id }
        return mock[i]
      }
      throw new Error('not found')
    }
  },

  async remove(id: string): Promise<void> {
    if (!USE_MOCK) {
      const res = await fetch(`${BASE}/personnel/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Failed to delete')
    } else {
      await loadMock()
      mock = mock.filter(x => x.人材ID !== id)
    }
  }
}
