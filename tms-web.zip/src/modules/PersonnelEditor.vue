
<template>
  <BaseModal :open="open" :title="isNew ? '新規登録' : '編集'" @close="onCancel">
    <div class="form-grid">
      <div>
        <div class="label">人材ID（自動生成・編集不可）</div>
        <input :value="model.人材ID || '(新規作成時に自動生成)'" disabled />
      </div>

      <div>
        <div class="label">所属会社</div>
        <input v-model="model.所属会社" />
      </div>

      <div>
        <div class="label">名前</div>
        <input v-model="model.名前" />
      </div>

      <div>
        <div class="label">社員番号</div>
        <input v-model="model.社員番号" />
      </div>

      <div>
        <div class="label">生年月日（YYYYMMDD）</div>
        <input v-model="model.生年月日" placeholder="19900415" />
      </div>

      <div>
        <div class="label">現案件終了年月日（YYYYMMDD）</div>
        <input v-model="model.現案件終了年月日" placeholder="20251231" />
      </div>

      <div>
        <div class="label">BPフラグ</div>
        <select v-model.number="model.BPフラグ">
          <option :value="0">0</option>
          <option :value="1">1</option>
        </select>
      </div>

      <div>
        <div class="label">削除フラグ</div>
        <select v-model.number="model.削除フラグ">
          <option :value="0">0</option>
          <option :value="1">1</option>
        </select>
      </div>
    </div>

    <template #footer>
      <button class="btn" @click="onCancel">キャンセル</button>
      <button class="btn primary" @click="onSave">保存</button>
    </template>
  </BaseModal>
</template>

<script setup lang="ts">
import { reactive, watch, computed } from 'vue'
import type { Personnel } from './types'
import BaseModal from '../components/base/BaseModal.vue'

const props = defineProps<{
  open: boolean
  value?: Personnel | null
}>()
const emit = defineEmits<{
  (e: 'cancel'): void
  (e: 'save', value: Personnel, isNew: boolean): void
}>()

const model = reactive<Personnel>({
  人材ID: '',
  所属会社: '',
  名前: '',
  社員番号: '',
  生年月日: '',
  現案件終了年月日: '',
  BPフラグ: 0,
  削除フラグ: 0
})

watch(() => props.value, (v) => {
  if (v) Object.assign(model, v)
  else Object.assign(model, { 人材ID: '', 所属会社: '', 名前: '', 社員番号: '', 生年月日: '', 現案件終了年月日: '', BPフラグ: 0, 削除フラグ: 0 })
}, { immediate: true })

const isNew = computed(() => !props.value || !props.value.人材ID)

function onCancel() { emit('cancel') }

function onSave() {
  // 人材IDは新規時のみ自動採番（画面編集不可）
  const payload: Personnel = {
    ...model,
    人材ID: isNew.value ? (crypto.randomUUID?.() ?? Math.random().toString(36).slice(2)) : model.人材ID
  }
  emit('save', payload, isNew.value)
}
</script>
